"""Create by Safwane 5/10/2020
   https://matplotlib.org/3.3.2/api/_as_gen/matplotlib.pyplot.plot.html for plot format"""


import os
import matplotlib.pyplot as plt
import numpy as np

pas=5
n_iteration=20

def run(exo): # n= itération    exo = numero de l'exercice
    f=open("size.txt","w")
    f.close()
    f = open("result.txt", "w")
    f.close()
    x = 'python3 -m am simulate EXO'+str(exo)+'.txt -t "XX<X>"'
    X = "XX<X>"
    for i in range(n_iteration):
        os.system(x)
        Y=X
        X = X.replace("<X>", "X")
        X += (pas - 1) * "X"
        X += "<X>"
        print(X)
        #X+=pas*"X"
        """Y=X
        X=X.replace("<X>","X")
        X += (pas - 1) * "X"
        X+="<X>" """
        y = x
        x = y.replace(Y, X)

# copy fichier size.txt dans un fichier size_i.txt
def copy(i):
    f=open("size"+str(i)+".txt","w")
    g=open("size.txt","r")
    f.write(g.read())


def read(exo=""): # exo = numero de l'exercice
    f = open("size"+str(exo)+".txt")
    t = []
    lines = f.readlines()
    for line in lines:
        t.append(int(line))
    return t

def plot(exo): # exo = numero de l'exercice
    x,y=[],read()
    for i in range(len(y)):
        x.append(pas*i)
    plt.plot(x,y,"-p",label="donnée")
    x = np.linspace(1, (n_iteration-1)*pas, 5*pas*n_iteration)
    if exo==1 or exo==2:
        y = x**2/3+10
    elif exo==3:
        y=x*np.lo
    elif exo==4:
        y = 5*(x+1)
    plt.plot(x, y,"-g",label="fonction")
    y=x*np.log2(x)
    plt.plot(x, y, "-*", label="fonction x*log(x)")
    plt.legend(loc="upper left")
    plt.show()

def readResult(exo=""): # exo = numero de l'exercice
    f = open("result"+str(exo)+".txt")
    t = []
    lines = f.readlines()
    for line in lines:
        t.append(line)
    return t

def verif():
    t=readResult()
    for i in range(len(t)):
        cl = cm = cn = 0
        for l in t[i]:
            if l=='L':
                cl+=1
            elif l=='M':
                cm+=1
            elif l=='N':
                cn+=1
        print(calculModulo(cl, cm, cn))


def calculModulo(l,m,n):
    nb=l+m+n
    if nb%3==0:
        if not (l==m and m==n):
            return "faux on devrait avoir l=m=n"
        else:
            return "vrai"
    elif nb%3==1:
        if l==m and m+1==n:
            return "vrai"
        else:
            return "faux on devrait avoir n+1"
    else:
        if l+1==m and m==n:
            return "vrai"
        else:
            return "faux on devrait avoir n+1 et m+1"

#copy(4)
#run(2)
#verif()
plot(2)