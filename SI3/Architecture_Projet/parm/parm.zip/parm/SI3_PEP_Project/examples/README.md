# Examples

## Calculator

C code example using memory mapped IO.

Basic 8-bit integer calculator with support for addition, subtraction, multiplication and left shift.

Note: C compiler will generate addresses multiples of 4. It has to be taken into account either when generating the ROM code or in the Logisim circuit.
