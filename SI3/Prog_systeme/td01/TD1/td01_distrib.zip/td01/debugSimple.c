#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    int z =  argc;
    char *prog = argv[0];
    char *arg = argv[1];

    int *w = &z;
    
    printf("bonjour\n");
}