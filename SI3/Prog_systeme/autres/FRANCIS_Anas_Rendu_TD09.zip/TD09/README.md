Author: FRANCIS Anas
Class : SI3


Il suffit de lancer la commande 'make' pour lancer le programme HellowWrold en Java.
Si une erreur a été provoqué veuillez lancez les commandes suivantes dans l'ordre:
	'LD_LIBRARY_PATH=D_LIBRARY_PATH:C_files'
	'export LD_LIBRARY_PATH'
