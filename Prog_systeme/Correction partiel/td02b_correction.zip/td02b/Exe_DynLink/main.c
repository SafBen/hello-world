extern void PrintStop(char*);

int main()
{
	char a[] = "test";

	PrintStop(a);
}
