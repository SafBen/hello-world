#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>
#include <unistd.h>
#include "util.h"
#include <dirent.h>













int main(int argc, char** argv){
    printf("Hello world!\n");
    return 0;
}