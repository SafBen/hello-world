int main(int argc, char *argv[])
{
    int tab[] = {12,45,67,789};
    int *ii=tab;
    short *si=tab;
    char *ci=tab;
    ii++;
    si++;
    ci++;
}